﻿using Microsoft.EntityFrameworkCore;
using $safeprojectname$.Entities;

namespace $safeprojectname$
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext()
        {
            
        }

        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {

        }

        public DbSet<Event> Events { get; set; }
    }
}
