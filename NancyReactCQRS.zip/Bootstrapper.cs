﻿using System.IO;
using Nancy;
using Nancy.Conventions;

namespace $safeprojectname$
{
    public class Bootstrapper : DefaultNancyBootstrapper
    {
        protected override void ConfigureConventions(NancyConventions nancyConventions)
        {
            nancyConventions.StaticContentsConventions.Add(StaticContentConventionBuilder.AddDirectory("/", @"Content"));

            base.ConfigureConventions(nancyConventions);
        }
    }

    public class DemoRootPathProvider : IRootPathProvider
    {
        public string GetRootPath()
        {
            return Directory.GetCurrentDirectory();
        }
    }
}
