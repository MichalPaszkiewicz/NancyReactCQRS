﻿import * as React from 'react';
import { Router, Route, ApplicationService, Page } from 'cqrs-react-router';
import { NotFound } from "./notfound";
import { Home } from "./pages/home";

export class App extends React.Component<any, any>{
    constructor(props) {
        super(props);
        var self = this;
    }
    render() {
        var self = this;

        return (
            <div className="container-fluid">
                <Router applicationService={new ApplicationService()}>
                    <Route path="/" component={Home} />
                    <Route path="*" component={NotFound} />
                </Router>
            </div>
        )
    }
}
