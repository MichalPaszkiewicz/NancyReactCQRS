﻿import * as React from 'react';
import { Page } from 'cqrs-react-router';

export class NotFound extends Page{
    render() {
        return (
            <div className="container-fluid">
                <h1>
                    404 - Not Found
                </h1>
            </div>
        )
    }
}