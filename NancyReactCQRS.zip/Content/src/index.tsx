﻿import * as React from "react";
import * as ReactDom from "react-dom";
import { App } from "./app";

declare function require(name: string): any;
require("../less/index.less");

ReactDom.render(
    <App />,
    document.getElementById("wrapper")
);