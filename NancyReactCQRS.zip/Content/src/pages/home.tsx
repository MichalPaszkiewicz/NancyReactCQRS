﻿import * as React from 'react';
import { Page } from "cqrs-react-router";

export class Home extends Page{
    render() {
        return (
            <div>
                <h1>$safeprojectname$</h1>
            </div>
        )
    }
}

