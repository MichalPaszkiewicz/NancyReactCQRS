﻿using System;

namespace $safeprojectname$.Entities
{
    public class Event
    {
        public Guid Id { get; set; }

    }
}
