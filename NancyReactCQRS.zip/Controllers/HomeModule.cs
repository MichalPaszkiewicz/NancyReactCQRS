﻿using Nancy;

namespace $safeprojectname$.Controllers
{
    public class HomeModule : NancyModule
    {
        public HomeModule()
        {
            Get("/", args => Response.AsFile("Content/index.html", "text/html"));
        }
    }
}
