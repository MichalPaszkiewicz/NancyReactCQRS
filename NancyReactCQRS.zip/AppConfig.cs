﻿namespace $safeprojectname$
{
    public class AppConfig
    {
        public string ConnectionString { get; set; }
    }
}